import { defineConfig } from 'cypress';

// Cypress у проєкті використовується лише для e2e-тестів, юніт- і компонентні тести працюють на Vitest.
export default defineConfig({
  e2e: {
    baseUrl: 'http://localhost:5173',
    specPattern: 'cypress/e2e/**/*.cy.js',
    supportFile: 'cypress/support/e2e.js',
  },
});
