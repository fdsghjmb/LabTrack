import { QueryClientProvider } from '@tanstack/react-query';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, expect, it, vi } from 'vitest';
import { USER, loginAs, makeClient, makeLab, mockApi } from '../test/utils';
import App from './App';

vi.mock('../shared/lib/api', async (importOriginal) => ({
  ...(await importOriginal()),
  api: vi.fn(),
}));

// App використовує BrowserRouter, тому початкову адресу задаємо через history.
function renderApp(path) {
  window.history.pushState({}, '', path);
  return render(
    <QueryClientProvider client={makeClient()}>
      <App />
    </QueryClientProvider>,
  );
}

describe('App: маршрутизація', () => {
  it('неавторизованого користувача з закритої сторінки веде на вхід', async () => {
    mockApi({});
    renderApp('/labs');
    expect(await screen.findByRole('button', { name: 'Увійти' })).toBeInTheDocument();
    expect(window.location.pathname).toBe('/login');
  });

  it('авторизований користувач бачить головну сторінку', async () => {
    mockApi({ ...loginAs(), 'GET /labs': () => [] });
    renderApp('/');
    expect(
      await screen.findByRole('heading', { name: `Вітаємо, ${USER.name}!` }),
    ).toBeInTheDocument();
  });

  it('невідомий шлях веде на головну', async () => {
    mockApi({ ...loginAs(), 'GET /labs': () => [] });
    renderApp('/qwerty');
    expect(await screen.findByRole('heading', { name: /Вітаємо/ })).toBeInTheDocument();
    expect(window.location.pathname).toBe('/');
  });

  it('сторінка входу для авторизованого веде до списку', async () => {
    mockApi({ ...loginAs(), 'GET /labs': () => [] });
    renderApp('/login');
    expect(
      await screen.findByRole('heading', { name: 'Мої лабораторні' }),
    ).toBeInTheDocument();
    expect(window.location.pathname).toBe('/labs');
  });

  it('навігація між сторінками працює через меню й посилання', async () => {
    const lab = makeLab({ title: 'Роутінг' });
    mockApi({ ...loginAs(), 'GET /labs': () => [lab] });
    const user = userEvent.setup();
    renderApp('/');
    await screen.findByRole('heading', { name: /Вітаємо/ });

    await user.click(screen.getByRole('link', { name: 'Мої лабораторні' }));
    expect(
      await screen.findByRole('heading', { name: 'Мої лабораторні' }),
    ).toBeInTheDocument();

    await user.click(screen.getByRole('link', { name: 'Змінити' }));
    expect(
      await screen.findByRole('heading', { name: 'Редагувати лабораторну' }),
    ).toBeInTheDocument();
    expect(window.location.pathname).toBe(`/labs/${lab.id}/edit`);

    await user.click(screen.getByRole('button', { name: 'Скасувати' }));
    expect(
      await screen.findByRole('heading', { name: 'Мої лабораторні' }),
    ).toBeInTheDocument();
  });

  it('сторінка додавання відкривається з посилання на списку', async () => {
    mockApi({ ...loginAs(), 'GET /labs': () => [makeLab()] });
    const user = userEvent.setup();
    renderApp('/labs');
    await user.click(await screen.findByRole('link', { name: '+ Додати лабораторну' }));
    expect(
      await screen.findByRole('heading', { name: 'Додати лабораторну' }),
    ).toBeInTheDocument();
  });
});
