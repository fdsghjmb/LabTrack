import { screen, waitFor } from '@testing-library/react';
import { Route, Routes } from 'react-router-dom';
import { describe, expect, it, vi } from 'vitest';
import { failWith, loginAs, mockApi, renderWithProviders } from '../../test/utils';
import ProtectedRoute from './ProtectedRoute';

vi.mock('../../shared/lib/api', async (importOriginal) => ({
  ...(await importOriginal()),
  api: vi.fn(),
}));

function renderGuarded() {
  return renderWithProviders(null, {
    route: '/secret',
    routes: (
      <Routes>
        <Route path="/login" element={<p>Сторінка входу</p>} />
        <Route element={<ProtectedRoute />}>
          <Route path="/secret" element={<p>Закритий вміст</p>} />
        </Route>
      </Routes>
    ),
  });
}

describe('ProtectedRoute', () => {
  it('без токена перенаправляє на вхід і не робить запитів', async () => {
    const calls = mockApi({});
    renderGuarded();
    expect(await screen.findByText('Сторінка входу')).toBeInTheDocument();
    expect(calls).toHaveLength(0);
  });

  it('показує індикатор, поки перевіряється токен, а потім вміст', async () => {
    mockApi({ ...loginAs() });
    renderGuarded();
    expect(screen.getByText('Завантаження…')).toBeInTheDocument();
    expect(await screen.findByText('Закритий вміст')).toBeInTheDocument();
  });

  it('перенаправляє на вхід і стирає токен, якщо сервер повернув 401', async () => {
    mockApi({ 'GET /auth/me': failWith('Сесія недійсна', 401) });
    localStorage.setItem('labtrack.token', JSON.stringify('expired'));
    renderGuarded();
    expect(await screen.findByText('Сторінка входу')).toBeInTheDocument();
    await waitFor(() => expect(localStorage.getItem('labtrack.token')).toBeNull());
  });

  it('залишає токен, якщо помилка не пов’язана з авторизацією', async () => {
    mockApi({ 'GET /auth/me': failWith('Помилка сервера', 500) });
    localStorage.setItem('labtrack.token', JSON.stringify('valid'));
    renderGuarded();
    expect(await screen.findByText('Сторінка входу')).toBeInTheDocument();
    expect(localStorage.getItem('labtrack.token')).not.toBeNull();
  });
});
