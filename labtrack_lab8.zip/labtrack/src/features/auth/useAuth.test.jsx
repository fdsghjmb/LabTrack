import { QueryClientProvider } from '@tanstack/react-query';
import { act, renderHook, waitFor } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import { USER, failWith, loginAs, makeClient, mockApi } from '../../test/utils';
import { useAuth } from './useAuth';

vi.mock('../../shared/lib/api', async (importOriginal) => ({
  ...(await importOriginal()),
  api: vi.fn(),
}));

function setup() {
  const client = makeClient();
  const wrapper = ({ children }) => (
    <QueryClientProvider client={client}>{children}</QueryClientProvider>
  );
  return { client, ...renderHook(() => useAuth(), { wrapper }) };
}

describe('useAuth', () => {
  it('без токена користувача немає й запит не виконується', () => {
    const calls = mockApi({});
    const { result } = setup();
    expect(result.current.user).toBeNull();
    expect(result.current.isLoading).toBe(false);
    expect(calls).toHaveLength(0);
  });

  it('з токеном завантажує користувача', async () => {
    mockApi({ ...loginAs() });
    const { result } = setup();
    expect(result.current.isLoading).toBe(true);
    await waitFor(() => expect(result.current.user).toEqual(USER));
  });

  it('вхід зберігає токен і користувача та скидає кеш лабораторних', async () => {
    mockApi({ 'POST /auth/login': () => ({ token: 'new-token', user: USER }) });
    const { result, client } = setup();
    client.setQueryData(['labs'], [{ id: 'old' }]);

    await act(() =>
      result.current.login.mutateAsync({ email: USER.email, password: 'secret123' }),
    );

    await waitFor(() => expect(result.current.user).toEqual(USER));
    expect(JSON.parse(localStorage.getItem('labtrack.token'))).toBe('new-token');
    expect(client.getQueryData(['labs'])).toBeUndefined();
  });

  it('реєстрація працює так само, як вхід', async () => {
    const calls = mockApi({ 'POST /auth/register': () => ({ token: 't', user: USER }) });
    const { result } = setup();
    await act(() =>
      result.current.register.mutateAsync({
        name: 'Олена',
        email: USER.email,
        password: 'secret123',
      }),
    );
    expect(calls[0].key).toBe('POST /auth/register');
    await waitFor(() => expect(result.current.user).toEqual(USER));
  });

  it('помилка входу потрапляє в стан мутації, токен не зберігається', async () => {
    mockApi({ 'POST /auth/login': failWith('Невірна пошта або пароль', 401) });
    const { result } = setup();
    await act(async () => {
      await result.current.login
        .mutateAsync({ email: 'a@b.ua', password: 'bad' })
        .catch(() => {});
    });
    await waitFor(() =>
      expect(result.current.login.error?.message).toBe('Невірна пошта або пароль'),
    );
    expect(localStorage.getItem('labtrack.token')).toBeNull();
  });

  it('вихід видаляє токен, користувача та кеш лабораторних', async () => {
    mockApi({ ...loginAs() });
    const { result, client } = setup();
    await waitFor(() => expect(result.current.user).toEqual(USER));
    client.setQueryData(['labs'], [{ id: '1' }]);

    act(() => result.current.logout());

    await waitFor(() => expect(result.current.user).toBeNull());
    expect(localStorage.getItem('labtrack.token')).toBeNull();
    expect(client.getQueryData(['labs'])).toBeUndefined();
  });
});
