import { screen, waitFor } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import { failWith, makeLab, mockApi, renderWithProviders } from '../../test/utils';
import LabForm from './LabForm';

vi.mock('../../shared/lib/api', async (importOriginal) => ({
  ...(await importOriginal()),
  api: vi.fn(),
}));

async function fillNew(
  user,
  { subject = 'Веб', number = '2', title = 'Тема', deadline = '2030-01-15' } = {},
) {
  await user.type(screen.getByLabelText('Предмет'), subject);
  await user.type(screen.getByLabelText('Номер'), number);
  await user.type(screen.getByLabelText('Назва роботи'), title);
  await user.type(screen.getByLabelText('Дедлайн'), deadline);
}

describe('LabForm', () => {
  it('нова форма порожня зі статусом «Не розпочато»', () => {
    mockApi({});
    renderWithProviders(<LabForm />);
    expect(screen.getByLabelText('Предмет')).toHaveValue('');
    expect(screen.getByLabelText('Статус')).toHaveValue('todo');
  });

  it('створює лабораторну й переходить до списку', async () => {
    const calls = mockApi({ 'POST /labs': ({ body }) => ({ id: 'new', ...body }) });
    const { user } = renderWithProviders(<LabForm />);
    await fillNew(user);
    await user.selectOptions(screen.getByLabelText('Статус'), 'work');
    await user.click(screen.getByRole('button', { name: 'Зберегти' }));

    expect(await screen.findByText('Сторінка списку')).toBeInTheDocument();
    expect(calls[0].key).toBe('POST /labs');
    expect(calls[0].body).toMatchObject({
      subject: 'Веб',
      number: '2',
      title: 'Тема',
      deadline: '2030-01-15',
      status: 'work',
    });
  });

  it('редагування заповнює поля й надсилає PATCH з id', async () => {
    const lab = makeLab({
      subject: 'Алгоритми',
      title: 'Сортування',
      deadline: '2030-03-01',
    });
    const calls = mockApi({ 'PATCH /labs/:id': ({ body }) => ({ ...lab, ...body }) });
    const { user } = renderWithProviders(<LabForm lab={lab} />);
    expect(screen.getByLabelText('Предмет')).toHaveValue('Алгоритми');

    await user.clear(screen.getByLabelText('Назва роботи'));
    await user.type(screen.getByLabelText('Назва роботи'), 'Швидке сортування');
    await user.click(screen.getByRole('button', { name: 'Зберегти' }));

    await screen.findByText('Сторінка списку');
    expect(calls[0].path).toBe(`/labs/${lab.id}`);
    expect(calls[0].body.title).toBe('Швидке сортування');
  });

  it('показує помилку сервера й лишається на формі', async () => {
    mockApi({ 'POST /labs': failWith('Номер має бути цілим числом від 1') });
    const { user } = renderWithProviders(<LabForm />);
    await fillNew(user);
    await user.click(screen.getByRole('button', { name: 'Зберегти' }));

    expect(
      await screen.findByText('Номер має бути цілим числом від 1'),
    ).toBeInTheDocument();
    expect(screen.queryByText('Сторінка списку')).not.toBeInTheDocument();
  });

  it('блокує кнопку й показує «Збереження…» під час запиту', async () => {
    let finish;
    mockApi({
      'POST /labs': () =>
        new Promise((resolve) => {
          finish = () => resolve({ id: 'x' });
        }),
    });
    const { user } = renderWithProviders(<LabForm />);
    await fillNew(user);
    await user.click(screen.getByRole('button', { name: 'Зберегти' }));

    expect(await screen.findByRole('button', { name: 'Збереження…' })).toBeDisabled();
    finish();
    await screen.findByText('Сторінка списку');
  });

  it('«Скасувати» повертає до списку без запитів', async () => {
    const calls = mockApi({});
    const { user } = renderWithProviders(<LabForm />);
    await user.click(screen.getByRole('button', { name: 'Скасувати' }));
    await waitFor(() => expect(screen.getByText('Сторінка списку')).toBeInTheDocument());
    expect(calls).toHaveLength(0);
  });
});
