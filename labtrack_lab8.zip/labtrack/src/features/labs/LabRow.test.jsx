import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';
import { describe, expect, it, vi } from 'vitest';
import { daysFromNow, makeLab, routerFuture } from '../../test/utils';
import LabRow from './LabRow';

function setup(lab, handlers = {}) {
  const props = { onStatusChange: vi.fn(), onRemove: vi.fn(), ...handlers };
  render(
    <MemoryRouter future={routerFuture}>
      <table>
        <tbody>
          <LabRow lab={lab} {...props} />
        </tbody>
      </table>
    </MemoryRouter>,
  );
  return props;
}

describe('LabRow', () => {
  it('показує предмет, номер, назву й дату', () => {
    setup(
      makeLab({
        subject: 'Алгоритми',
        number: 3,
        title: 'Сортування',
        deadline: '2030-01-15',
      }),
    );
    expect(screen.getByText('Алгоритми')).toBeInTheDocument();
    expect(screen.getByText('Лаб. №3 «Сортування»')).toBeInTheDocument();
    expect(screen.getByText('15.01.2030')).toBeInTheDocument();
  });

  it('показує мітку терміновості для незахищеної роботи', () => {
    setup(makeLab({ deadline: daysFromNow(-2), status: 'work' }));
    expect(screen.getByText('Прострочено 2 дн.')).toHaveClass('urgency-overdue');
  });

  it('не показує мітку терміновості для захищеної роботи', () => {
    setup(makeLab({ deadline: daysFromNow(-2), status: 'defended' }));
    expect(screen.queryByText(/Прострочено/)).not.toBeInTheDocument();
  });

  it('викликає onStatusChange з id та новим статусом', async () => {
    const lab = makeLab();
    const { onStatusChange } = setup(lab);
    await userEvent.selectOptions(screen.getByLabelText('Змінити статус'), 'defended');
    expect(onStatusChange).toHaveBeenCalledWith(lab.id, 'defended');
  });

  it('викликає onRemove з id', async () => {
    const lab = makeLab();
    const { onRemove } = setup(lab);
    await userEvent.click(screen.getByRole('button', { name: 'Видалити' }));
    expect(onRemove).toHaveBeenCalledWith(lab.id);
  });

  it('має посилання на редагування з id лабораторної', () => {
    const lab = makeLab();
    setup(lab);
    const row = screen.getByRole('row');
    expect(within(row).getByRole('link', { name: 'Змінити' })).toHaveAttribute(
      'href',
      `/labs/${lab.id}/edit`,
    );
  });
});
