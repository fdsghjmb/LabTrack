import { describe, expect, it } from 'vitest';
import { daysLeft, formatDate, getUrgency } from './deadline';

const today = new Date(2026, 8, 20); // 20.09.2026

describe('deadline', () => {
  it('рахує різницю в календарних днях', () => {
    expect(daysLeft('2026-09-20', today)).toBe(0);
    expect(daysLeft('2026-09-27', today)).toBe(7);
    expect(daysLeft('2026-09-15', today)).toBe(-5);
  });

  it('не залежить від часу доби', () => {
    expect(daysLeft('2026-09-21', new Date(2026, 8, 20, 23, 59))).toBe(1);
  });

  it.each([
    ['2026-09-15', 'overdue', 'Прострочено 5 дн.'],
    ['2026-09-20', 'today', 'Сьогодні'],
    ['2026-09-23', 'soon', 'Через 3 дн.'],
    ['2026-09-24', 'ok', 'Через 4 дн.'],
  ])('дедлайн %s має рівень %s', (deadline, level, label) => {
    expect(getUrgency(deadline, today)).toEqual({ level, label });
  });

  it('використовує поточну дату за замовчуванням', () => {
    expect(getUrgency('2000-01-01').level).toBe('overdue');
  });

  it('форматує дату як ДД.ММ.РРРР', () => {
    expect(formatDate('2026-09-07')).toBe('07.09.2026');
  });
});
