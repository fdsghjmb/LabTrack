import { QueryClientProvider } from '@tanstack/react-query';
import { act, renderHook, waitFor } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import { makeClient, makeLab, mockApi } from '../../test/utils';
import { useCreateLab, useDeleteLab, useLabs, useUpdateLab } from './useLabs';

vi.mock('../../shared/lib/api', async (importOriginal) => ({
  ...(await importOriginal()),
  api: vi.fn(),
}));

function setup(hook) {
  const client = makeClient();
  const wrapper = ({ children }) => (
    <QueryClientProvider client={client}>{children}</QueryClientProvider>
  );
  return renderHook(hook, { wrapper });
}

describe('useLabs', () => {
  it('завантажує список лабораторних', async () => {
    const labs = [makeLab(), makeLab()];
    mockApi({ 'GET /labs': () => labs });
    const { result } = setup(() => useLabs());
    await waitFor(() => expect(result.current.data).toEqual(labs));
  });

  it('створення надсилає POST і перезавантажує список', async () => {
    let labs = [];
    const created = makeLab();
    const calls = mockApi({
      'GET /labs': () => labs,
      'POST /labs': ({ body }) => {
        labs = [{ ...created, ...body }];
        return labs[0];
      },
    });
    const { result } = setup(() => ({ list: useLabs(), create: useCreateLab() }));
    await waitFor(() => expect(result.current.list.data).toEqual([]));

    await act(() => result.current.create.mutateAsync({ title: 'Нова' }));

    await waitFor(() => expect(result.current.list.data).toHaveLength(1));
    expect(calls.filter((c) => c.key === 'GET /labs')).toHaveLength(2);
    expect(calls.find((c) => c.key === 'POST /labs').body).toEqual({ title: 'Нова' });
  });

  it('зміна надсилає PATCH на адресу з id без id в тілі', async () => {
    const lab = makeLab();
    const calls = mockApi({ 'GET /labs': () => [lab], 'PATCH /labs/:id': () => lab });
    const { result } = setup(() => ({ list: useLabs(), update: useUpdateLab() }));
    await waitFor(() => expect(result.current.list.data).toBeDefined());

    await act(() => result.current.update.mutateAsync({ id: lab.id, status: 'done' }));

    const patch = calls.find((c) => c.key === 'PATCH /labs/:id');
    expect(patch.path).toBe(`/labs/${lab.id}`);
    expect(patch.body).toEqual({ status: 'done' });
  });

  it('видалення надсилає DELETE', async () => {
    const lab = makeLab();
    const calls = mockApi({ 'GET /labs': () => [lab], 'DELETE /labs/:id': () => null });
    const { result } = setup(() => ({ list: useLabs(), remove: useDeleteLab() }));
    await waitFor(() => expect(result.current.list.data).toBeDefined());

    await act(() => result.current.remove.mutateAsync(lab.id));

    expect(calls.find((c) => c.key === 'DELETE /labs/:id').path).toBe(`/labs/${lab.id}`);
  });
});
