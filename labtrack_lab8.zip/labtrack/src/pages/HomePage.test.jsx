import { screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import {
  USER,
  daysFromNow,
  failWith,
  loginAs,
  makeLab,
  mockApi,
  renderWithProviders,
} from '../test/utils';
import HomePage from './HomePage';

vi.mock('../shared/lib/api', async (importOriginal) => ({
  ...(await importOriginal()),
  api: vi.fn(),
}));

function setup(labsHandler) {
  mockApi({ ...loginAs(), 'GET /labs': labsHandler });
  // Під ProtectedRoute користувач уже є в кеші, тому кладемо його туди напряму.
  return renderWithProviders(<HomePage />, {
    route: '/',
    path: '/',
    seed: [[['me'], USER]],
  });
}

describe('HomePage', () => {
  it('вітає користувача на ім’я', async () => {
    setup(() => []);
    expect(
      await screen.findByRole('heading', { name: `Вітаємо, ${USER.name}!` }),
    ).toBeInTheDocument();
  });

  it('показує індикатор завантаження списку', async () => {
    setup(() => new Promise(() => {}));
    expect(await screen.findByText('Завантаження…')).toBeInTheDocument();
  });

  it('показує повідомлення, якщо активних лабораторних немає', async () => {
    setup(() => [makeLab({ status: 'defended' })]);
    expect(
      await screen.findByText('Активних лабораторних поки немає.'),
    ).toBeInTheDocument();
  });

  it('показує три найближчі незахищені роботи за дедлайном', async () => {
    setup(() => [
      makeLab({ title: 'Далека', deadline: daysFromNow(30) }),
      makeLab({ title: 'Захищена', deadline: daysFromNow(1), status: 'defended' }),
      makeLab({ title: 'Перша', deadline: daysFromNow(1), status: 'work' }),
      makeLab({ title: 'Друга', deadline: daysFromNow(2) }),
      makeLab({ title: 'Третя', deadline: daysFromNow(5) }),
    ]);
    expect(await screen.findByText(/«Перша»/)).toBeInTheDocument();
    expect(screen.getByText(/«Друга»/)).toBeInTheDocument();
    expect(screen.getByText(/«Третя»/)).toBeInTheDocument();
    expect(screen.queryByText(/«Далека»/)).not.toBeInTheDocument();
    expect(screen.queryByText(/«Захищена»/)).not.toBeInTheDocument();
  });

  it('показує мітки терміновості й статусу', async () => {
    setup(() => [makeLab({ deadline: daysFromNow(0), status: 'work' })]);
    expect(await screen.findByText('Сьогодні')).toHaveClass('urgency-today');
    expect(screen.getByText('В роботі')).toHaveClass('status-work');
  });

  it('показує текст помилки, якщо список не завантажився', async () => {
    setup(failWith('Сервер недоступний', 0));
    expect(await screen.findByText('Сервер недоступний')).toBeInTheDocument();
  });

  it('має посилання на додавання лабораторної', async () => {
    setup(() => []);
    expect(
      await screen.findByRole('link', { name: '+ Додати лабораторну' }),
    ).toHaveAttribute('href', '/labs/new');
  });
});
