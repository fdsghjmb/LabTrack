import { screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import { makeLab, mockApi, renderWithProviders } from '../test/utils';
import LabFormPage from './LabFormPage';

vi.mock('../shared/lib/api', async (importOriginal) => ({
  ...(await importOriginal()),
  api: vi.fn(),
}));

function setup(route, list) {
  mockApi({ 'GET /labs': list });
  return renderWithProviders(<LabFormPage />, {
    route,
    path: route.includes('/edit') ? '/labs/:id/edit' : '/labs/new',
  });
}

describe('LabFormPage', () => {
  it('на маршруті /labs/new показує порожню форму додавання', async () => {
    setup('/labs/new', () => []);
    expect(
      await screen.findByRole('heading', { name: 'Додати лабораторну' }),
    ).toBeInTheDocument();
    expect(screen.getByLabelText('Предмет')).toHaveValue('');
  });

  it('на маршруті редагування показує заповнену форму', async () => {
    const lab = makeLab({ subject: 'Алгоритми', title: 'Сортування' });
    setup(`/labs/${lab.id}/edit`, () => [lab]);
    expect(
      await screen.findByRole('heading', { name: 'Редагувати лабораторну' }),
    ).toBeInTheDocument();
    expect(screen.getByLabelText('Предмет')).toHaveValue('Алгоритми');
    expect(screen.getByLabelText('Назва роботи')).toHaveValue('Сортування');
  });

  it('показує індикатор, поки лабораторні завантажуються', () => {
    setup('/labs/abc/edit', () => new Promise(() => {}));
    expect(screen.getByText('Завантаження…')).toBeInTheDocument();
  });

  it('для неіснуючого id показує повідомлення, а не порожню форму', async () => {
    setup('/labs/nope/edit', () => [makeLab()]);
    expect(await screen.findByText('Лабораторну не знайдено.')).toBeInTheDocument();
    expect(screen.queryByLabelText('Предмет')).not.toBeInTheDocument();
  });
});
