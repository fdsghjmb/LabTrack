import { screen, within } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import {
  daysFromNow,
  failWith,
  makeLab,
  mockApi,
  renderWithProviders,
} from '../test/utils';
import LabsPage from './LabsPage';

vi.mock('../shared/lib/api', async (importOriginal) => ({
  ...(await importOriginal()),
  api: vi.fn(),
}));

const labs = () => [
  makeLab({ subject: 'Веб', title: 'Мокапи', deadline: daysFromNow(9), status: 'work' }),
  makeLab({
    subject: 'Алгоритми',
    title: 'Сортування',
    deadline: daysFromNow(2),
    status: 'defended',
  }),
  makeLab({
    subject: 'Бази даних',
    title: 'Таблиці',
    deadline: daysFromNow(5),
    status: 'todo',
  }),
];

function setup(handlers = {}, list = labs) {
  const calls = mockApi({ 'GET /labs': list, ...handlers });
  return {
    calls,
    ...renderWithProviders(<LabsPage />, { route: '/labs', path: '/labs' }),
  };
}

const rowTexts = () =>
  screen
    .getAllByRole('row')
    .slice(1)
    .map((row) => within(row).getAllByRole('cell')[0].textContent);

describe('LabsPage', () => {
  it('показує індикатор завантаження', async () => {
    setup({}, () => new Promise(() => {}));
    expect(await screen.findByText('Завантаження…')).toBeInTheDocument();
  });

  it('показує помилку завантаження', async () => {
    setup({}, failWith('Сервер недоступний', 0));
    expect(await screen.findByText('Сервер недоступний')).toBeInTheDocument();
  });

  it('показує таблицю, відсортовану за дедлайном', async () => {
    setup();
    await screen.findByRole('table');
    expect(rowTexts()).toEqual(['Алгоритми', 'Бази даних', 'Веб']);
  });

  it('показує прогрес семестру', async () => {
    setup();
    expect(await screen.findByText('1 з 3 захищено · 33%')).toBeInTheDocument();
  });

  it('показує нульовий прогрес без лабораторних і повідомлення про порожній список', async () => {
    setup({}, () => []);
    expect(await screen.findByText('Лабораторних не знайдено.')).toBeInTheDocument();
    expect(screen.getByText('0 з 0 захищено · 0%')).toBeInTheDocument();
  });

  it('фільтрує за статусом', async () => {
    const { user } = setup();
    await screen.findByRole('table');
    await user.click(screen.getByRole('button', { name: 'Захищено' }));
    expect(rowTexts()).toEqual(['Алгоритми']);
    await user.click(screen.getByRole('button', { name: 'Усі' }));
    expect(rowTexts()).toHaveLength(3);
  });

  it('шукає за предметом і назвою без урахування регістру', async () => {
    const { user } = setup();
    await screen.findByRole('table');
    await user.type(screen.getByLabelText('Пошук'), 'МОКАПИ');
    expect(rowTexts()).toEqual(['Веб']);
    await user.clear(screen.getByLabelText('Пошук'));
    await user.type(screen.getByLabelText('Пошук'), 'немає такої');
    expect(screen.getByText('Лабораторних не знайдено.')).toBeInTheDocument();
  });

  it('зміна статусу надсилає PATCH і оновлює список', async () => {
    let data = labs();
    const { user, calls } = setup(
      {
        'GET /labs': () => data,
        'PATCH /labs/:id': ({ path, body }) => {
          const id = path.split('/').pop();
          data = data.map((l) => (l.id === id ? { ...l, ...body } : l));
          return data.find((l) => l.id === id);
        },
      },
      () => data,
    );
    await screen.findByRole('table');
    const selects = screen.getAllByLabelText('Змінити статус');
    await user.selectOptions(selects[1], 'defended');

    expect(await screen.findByText('2 з 3 захищено · 67%')).toBeInTheDocument();
    expect(calls.find((c) => c.key === 'PATCH /labs/:id').body).toEqual({
      status: 'defended',
    });
  });

  it('видалення надсилає DELETE і прибирає рядок', async () => {
    let data = labs();
    const { user, calls } = setup(
      {
        'GET /labs': () => data,
        'DELETE /labs/:id': ({ path }) => {
          data = data.filter((l) => l.id !== path.split('/').pop());
          return null;
        },
      },
      () => data,
    );
    await screen.findByRole('table');
    await user.click(screen.getAllByRole('button', { name: 'Видалити' })[0]);

    await vi.waitFor(() => expect(rowTexts()).toHaveLength(2));
    expect(calls.some((c) => c.key === 'DELETE /labs/:id')).toBe(true);
  });

  it('має посилання на додавання лабораторної', async () => {
    setup();
    expect(
      await screen.findByRole('link', { name: '+ Додати лабораторну' }),
    ).toHaveAttribute('href', '/labs/new');
  });
});
