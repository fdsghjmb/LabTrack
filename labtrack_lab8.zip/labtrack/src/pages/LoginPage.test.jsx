import { screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import { USER, failWith, loginAs, mockApi, renderWithProviders } from '../test/utils';
import LoginPage from './LoginPage';

vi.mock('../shared/lib/api', async (importOriginal) => ({
  ...(await importOriginal()),
  api: vi.fn(),
}));

const setup = () =>
  renderWithProviders(<LoginPage />, { route: '/login', path: '/login' });

describe('LoginPage', () => {
  it('за замовчуванням показує форму входу без поля імені', () => {
    mockApi({});
    setup();
    expect(screen.getByRole('button', { name: 'Увійти' })).toBeInTheDocument();
    expect(screen.queryByLabelText('Ім’я')).not.toBeInTheDocument();
  });

  it('вкладка «Реєстрація» додає поле імені й змінює підпис кнопки', async () => {
    mockApi({});
    const { user } = setup();
    await user.click(screen.getByRole('button', { name: 'Реєстрація' }));
    expect(screen.getByLabelText('Ім’я')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Створити акаунт' })).toBeInTheDocument();
    await user.click(screen.getByRole('button', { name: 'Вхід' }));
    expect(screen.queryByLabelText('Ім’я')).not.toBeInTheDocument();
  });

  it('успішний вхід веде до списку лабораторних', async () => {
    const calls = mockApi({ 'POST /auth/login': () => ({ token: 't', user: USER }) });
    const { user } = setup();
    await user.type(screen.getByLabelText('Пошта'), USER.email);
    await user.type(screen.getByLabelText('Пароль'), 'secret123');
    await user.click(screen.getByRole('button', { name: 'Увійти' }));

    expect(await screen.findByText('Сторінка списку')).toBeInTheDocument();
    expect(calls[0].body).toEqual({ email: USER.email, password: 'secret123' });
  });

  it('реєстрація надсилає ім’я разом з обліковими даними', async () => {
    const calls = mockApi({ 'POST /auth/register': () => ({ token: 't', user: USER }) });
    const { user } = setup();
    await user.click(screen.getByRole('button', { name: 'Реєстрація' }));
    await user.type(screen.getByLabelText('Ім’я'), 'Олена');
    await user.type(screen.getByLabelText('Пошта'), USER.email);
    await user.type(screen.getByLabelText('Пароль'), 'secret123');
    await user.click(screen.getByRole('button', { name: 'Створити акаунт' }));

    expect(await screen.findByText('Сторінка списку')).toBeInTheDocument();
    expect(calls[0].key).toBe('POST /auth/register');
    expect(calls[0].body.name).toBe('Олена');
  });

  it('показує повідомлення про помилку й лишається на сторінці', async () => {
    mockApi({ 'POST /auth/login': failWith('Невірна пошта або пароль', 401) });
    const { user } = setup();
    await user.type(screen.getByLabelText('Пошта'), 'a@b.ua');
    await user.type(screen.getByLabelText('Пароль'), 'wrong-pass');
    await user.click(screen.getByRole('button', { name: 'Увійти' }));

    expect(await screen.findByText('Невірна пошта або пароль')).toBeInTheDocument();
    expect(screen.queryByText('Сторінка списку')).not.toBeInTheDocument();
  });

  it('блокує кнопку, поки триває запит', async () => {
    let finish;
    mockApi({
      'POST /auth/login': () =>
        new Promise((resolve) => {
          finish = () => resolve({ token: 't', user: USER });
        }),
    });
    const { user } = setup();
    await user.type(screen.getByLabelText('Пошта'), USER.email);
    await user.type(screen.getByLabelText('Пароль'), 'secret123');
    await user.click(screen.getByRole('button', { name: 'Увійти' }));

    expect(await screen.findByRole('button', { name: 'Зачекайте…' })).toBeDisabled();
    finish();
    await screen.findByText('Сторінка списку');
  });

  it('авторизованого користувача одразу перенаправляє до списку', async () => {
    mockApi({ ...loginAs() });
    setup();
    expect(await screen.findByText('Сторінка списку')).toBeInTheDocument();
  });
});
