import { screen, waitFor } from '@testing-library/react';
import { Route, Routes } from 'react-router-dom';
import { describe, expect, it, vi } from 'vitest';
import { USER, loginAs, mockApi, renderWithProviders } from '../../test/utils';
import Layout from './Layout';

vi.mock('../lib/api', async (importOriginal) => ({
  ...(await importOriginal()),
  api: vi.fn(),
}));

// У застосунку Layout стоїть під ProtectedRoute, тож користувач уже завантажений у кеш.
function renderLayout(route = '/') {
  mockApi({ ...loginAs() });
  return renderWithProviders(null, {
    route,
    seed: [[['me'], USER]],
    routes: (
      <Routes>
        <Route path="/login" element={<p>Сторінка входу</p>} />
        <Route element={<Layout />}>
          <Route index element={<p>Головний вміст</p>} />
          <Route path="labs" element={<p>Вміст списку</p>} />
          <Route path="labs/new" element={<p>Вміст форми</p>} />
        </Route>
      </Routes>
    ),
  });
}

describe('Layout', () => {
  it('показує логотип, ім’я користувача, вміст сторінки й підвал', async () => {
    renderLayout();
    expect(await screen.findByText(USER.name)).toBeInTheDocument();
    expect(screen.getByText('LabTrack')).toBeInTheDocument();
    expect(screen.getByText('Головний вміст')).toBeInTheDocument();
    expect(screen.getByText(/Навчальний проєкт/)).toBeInTheDocument();
  });

  it('підсвічує «Головну» лише на головній сторінці', async () => {
    renderLayout('/');
    await screen.findByText(USER.name);
    expect(screen.getByRole('link', { name: 'Головна' })).toHaveClass('active');
    expect(screen.getByRole('link', { name: 'Мої лабораторні' })).not.toHaveClass(
      'active',
    );
  });

  it('підсвічує «Мої лабораторні» і на вкладених адресах', async () => {
    renderLayout('/labs/new');
    await screen.findByText(USER.name);
    expect(screen.getByRole('link', { name: 'Мої лабораторні' })).toHaveClass('active');
    expect(screen.getByRole('link', { name: 'Головна' })).not.toHaveClass('active');
  });

  it('переходить між сторінками за посиланнями меню', async () => {
    const { user } = renderLayout('/');
    await screen.findByText(USER.name);
    await user.click(screen.getByRole('link', { name: 'Мої лабораторні' }));
    expect(screen.getByText('Вміст списку')).toBeInTheDocument();
  });

  it('вихід стирає токен і веде на сторінку входу', async () => {
    const { user } = renderLayout();
    await user.click(await screen.findByRole('button', { name: 'Вийти' }));
    expect(await screen.findByText('Сторінка входу')).toBeInTheDocument();
    await waitFor(() => expect(localStorage.getItem('labtrack.token')).toBeNull());
  });
});
