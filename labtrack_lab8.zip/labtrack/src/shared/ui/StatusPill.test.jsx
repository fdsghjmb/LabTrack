import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import StatusPill, { STATUSES } from './StatusPill';

describe('StatusPill', () => {
  it.each(Object.entries(STATUSES))(
    'показує підпис і клас для статусу %s',
    (key, label) => {
      render(<StatusPill status={key} />);
      const pill = screen.getByText(label);
      expect(pill).toHaveClass('pill', `status-${key}`);
    },
  );
});
