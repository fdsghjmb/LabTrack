import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { render } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { vi } from 'vitest';
import { ApiError, api } from '../shared/lib/api';

export const routerFuture = { v7_startTransition: true, v7_relativeSplatPath: true };

export const USER = { id: 'u1', name: 'Олена', email: 'olena@uzhnu.edu.ua' };

const DAY = 24 * 60 * 60 * 1000;

// Дата у форматі РРРР-ММ-ДД зі зсувом у днях від сьогодні, щоб тести не залежали від поточної дати.
export function daysFromNow(offset) {
  const d = new Date(Date.now() + offset * DAY);
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

let counter = 0;
export function makeLab(overrides = {}) {
  counter += 1;
  return {
    id: `lab-${counter}`,
    subject: 'Веб-технології',
    number: counter,
    title: `Тема ${counter}`,
    deadline: daysFromNow(10),
    status: 'todo',
    note: '',
    ...overrides,
  };
}

export function makeClient() {
  return new QueryClient({
    defaultOptions: { queries: { retry: false }, mutations: { retry: false } },
  });
}

// Імітує сервер: handlers мають ключі виду 'GET /labs', 'PATCH /labs/:id'.
// api у тестах підміняється через vi.mock('../shared/lib/api').
export function mockApi(handlers) {
  const calls = [];
  api.mockImplementation(async (path, { method = 'GET', body } = {}) => {
    const key = `${method} ${path.replace(/^\/labs\/[^/]+$/, '/labs/:id')}`;
    calls.push({ key, path, body });
    const handler = handlers[key];
    if (!handler) throw new Error(`Не змокано: ${key}`);
    return handler({ path, body });
  });
  return calls;
}

export function loginAs(user = USER) {
  localStorage.setItem('labtrack.token', JSON.stringify('test-token'));
  return { 'GET /auth/me': () => user };
}

export const failWith =
  (message, status = 400) =>
  () => {
    throw new ApiError(message, status);
  };

// Рендерить елемент у роутері й провайдері запитів. routes дозволяє додати сусідні маршрути.
export function renderWithProviders(
  ui,
  { route = '/', path = '*', routes = null, seed = [] } = {},
) {
  const client = makeClient();
  seed.forEach(([key, data]) => client.setQueryData(key, data));
  const user = userEvent.setup();
  const view = render(
    <QueryClientProvider client={client}>
      <MemoryRouter initialEntries={[route]} future={routerFuture}>
        {routes ?? (
          <Routes>
            <Route path={path} element={ui} />
            <Route path="/login" element={<p>Сторінка входу</p>} />
            <Route path="/labs" element={<p>Сторінка списку</p>} />
          </Routes>
        )}
      </MemoryRouter>
    </QueryClientProvider>,
  );
  return { ...view, user, client };
}

export { vi };
